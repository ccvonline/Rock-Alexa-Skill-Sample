'use strict';

const Alexa = require('ask-sdk');
// use 'ask-sdk' if standard SDK module is installed
// 

const constants = require('./constants');

// use https to make the call to the rock api for the verse of the day.

var https = require('https');

var AmazonDateParser = require('amazon-date-parser');
// Code for the handlers here

let skill;

exports.handler = function (event, context) {
  console.log(`REQUEST++++${JSON.stringify(event)}`);
  if (!skill) {
    skill = Alexa.SkillBuilders.standard()
      .addRequestHandlers(
        LaunchRequestHandler,
        VerseOfTheDayIntentHandler,
        SermonAudioIntentHandler,
        TipOfTheWeekIntentHandler,
        ThisWeekAtCCVIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        YesHandler,
        NoHandler,
        StartPlaybackHandler,
        NextPlaybackHandler,
        PreviousPlaybackHandler,
        PausePlaybackHandler,
        LoopOnHandler,
        LoopOffHandler,
        ShuffleOnHandler,
        ShuffleOffHandler,
        StartOverHandler,
        ExitHandler,
        AudioPlayerEventHandler,
      )
      .addErrorHandlers(ErrorHandler)
      .withAutoCreateTable(true)
      .withTableName(constants.skill.dynamoDBTableName)
      .addRequestInterceptors(LoadPersistentAttributesRequestInterceptor)
      .addResponseInterceptors(SavePersistentAttributesResponseInterceptor)
      .create();
  }
  
  return skill.invoke(event,context);

}

const LoadPersistentAttributesRequestInterceptor = {
  async process(handlerInput) {
    const persistentAttributes = await handlerInput.attributesManager.getPersistentAttributes();

    let pValues = {
        playbackSetting: {
          loop: false,
          shuffle: false,
        },
        playbackInfo: {
          sermonAudio:{
            id:0,
            lastItem:null,
            offsetInMilliseconds: 0,
            playbackIndexChanged: true,
            token: null,
            nextStreamEnqueued: false,
            inPlaybackSession: false,
            hasPreviousPlaybackSession: false,
          },
          tipOfTheWeek: {
            id: 0,
            lastItem:null,
            offsetInMilliseconds: 0,
            playbackIndexChanged: true,
            token: null,
            nextStreamEnqueued: false,
            inPlaybackSession: false,
            hasPreviousPlaybackSession: false,
          },
          thisWeekAtCCV:{
            id: 0,
            lastItem:null,
            offsetInMilliseconds: 0,
            playbackIndexChanged: true,
            token: null,
            nextStreamEnqueued: false,
            inPlaybackSession: false,
            hasPreviousPlaybackSession: false,
          },
          type: 'sermonAudio'
        }
    }

    // Check if user is invoking the skill the first time and initialize preset values
    if (Object.keys(persistentAttributes).length === 0) {
      handlerInput.attributesManager.setPersistentAttributes(pValues);
    }

  },
};

const SavePersistentAttributesResponseInterceptor = {
  async process(handlerInput) {
    await handlerInput.attributesManager.savePersistentAttributes();
  },
};

/**
 * Launch request handler, used to handle any request that does not include a specific intent.  
 * 
 * @type {LaunchRequestHandler}
 * 
 * @method canHandle is used to determine if this Request handle can be used to respond to a specific request.
 * Should simply return a bool value.  If true, the objects handle method will be called.
 * 
 * @method handle is called if canHandle returns true.  Must return either a respons object or, a promise which
 * should resolve with a response object. Documentation for using the response builder can be found her: https://ask-sdk-for-nodejs.readthedocs.io/en/latest/Response-Building.html
 * documentation for json response format can be found here: https://developer.amazon.com/docs/custom-skills/request-and-response-json-reference.html
 * 
 */
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {

        const speechText = 'Welcome to Christ\'s Church of the Valley! If you need help, just ask.';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Christ\'s Church of the Valley', speechText)
            .getResponse();
    }
};

const VerseOfTheDayIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'VerseOfTheDayIntent';
    },
    async handle(handlerInput) {

        let speechText = '';
        let displayText = '';
        let verseDate = null;
        let vData = null;
        let filterString = null;

        console.log('VersOfTheDayIntentHandler');

        if(handlerInput.requestEnvelope.request.intent.slots.for_date.hasOwnProperty('value')){
            verseDate = new Date(handlerInput.requestEnvelope.request.intent.slots.for_date.value);
        }else{
            verseDate = new Date();
        }

        filterString = 'ContentChannelId eq 249 and day(StartDateTime) eq ' +
                verseDate.getDate() + 
                ' and month(StartDateTime) eq ' + 
                (verseDate.getMonth()+1) +
                ' and year(StartDateTime) eq '
                +verseDate.getFullYear();

        let endPoint = '/api/ContentChannelItems?$filter='+encodeURIComponent(filterString)+'&LoadAttributes=True';

        let rData = await doRockRequest(endPoint);

        if(rData.length){
            vData = rData[0]
        }else{
            
            //if nothing was returned, check the previous month.
            filterString = 'ContentChannelId eq 249';

            console.log('FILTER STRING:', filterString);

            endPoint = '/api/ContentChannelItems?$filter='+
                encodeURIComponent(filterString)+
                '&LoadAttributes=True';

            rData = await doRockRequest(endPoint);

        }

        if(rData.length){
            rData.sort(dateSortDesc);
            console.log ('rData sorted: ', rData);
            let vData = rData[0];
            if('Introduction' in vData.AttributeValues){
                if(vData.AttributeValues.Introduction.Value.length > 1){
                    speechText += vData.AttributeValues.Introduction.Value + '<break time="1s"/>';
                    displayText += vData.AttributeValues.Introduction.Value;
                }
            }
            speechText += vData.Content;
            displayText += vData.Content;
            if('Verse' in vData.AttributeValues){
                speechText += ' ' + vData.AttributeValues.Verse.Value + '<break time="1s"/>';
                displayText += ' ' + vData.AttributeValues.Verse.Value;
            }
            if('Conclusion' in vData.AttributeValues){
                speechText += ' ' + vData.AttributeValues.Conclusion.Value;
                displayText += ' ' + vData.AttributeValues.Conclusion.Value;
            }

        }else{
            speechText = 'I\'m sorry, but I couldn\'t find any information that matches your request';
        }

        return handlerInput.responseBuilder
                .speak(speechText)
                .withSimpleCard('Verse Of The Day: ', displayText)
                .getResponse()
                .reprompt();
        
    }
};

const SermonAudioIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'SermonAudioIntent';
      },
      async handle(handlerInput) {
        const playbackInfo = await getPlaybackInfo(handlerInput);
        let message;
        let reprompt;
        let adate = null;

        playbackInfo.type = "sermonAudio";

        console.log('SERMON AUDIO HANDLER INPUT: ', handlerInput.requestEnvelope.request.intent.slots);

        if('value' in handlerInput.requestEnvelope.request.intent.slots.for_date){
          let awsDate = new AmazonDateParser(handlerInput.requestEnvelope.request.intent.slots.for_date.value);
          playbackInfo.forDate = awsDate.startDate.toJSON();
          console.log("START DATE:", playbackInfo.forDate);
        }else{
          playbackInfo.forDate = new Date();
          playbackInfo.forDate = playbackInfo.forDate.toJSON();
        }

        await setPlaybackInfo(handlerInput, playbackInfo);

        if (!playbackInfo.sermonAudio.hasPreviousPlaybackSession) {
          message = 'Welcome to the CCV Sermon Audio player.';
          //reprompt = 'You can say, play the audio, to begin.';
          return controller.play(handlerInput);
        } else {
          playbackInfo.sermonAudio.inPlaybackSession = false;

          //There was a problem getting the previously played sermon audio
          //reset the previous indicator and play the most current sermon audio.
          if(!playbackInfo.sermonAudio.lastItem){
            playbackInfo.sermonAudio.hasPreviousPlaybackSession = false
            playbackInfo.sermonAudio.offsetInMilliseconds = 0;
            return controller.play(handlerInput);
          }
          if(! ('Title' in playbackInfo.sermonAudio.lastItem)){
            playbackInfo.sermonAudio.hasPreviousPlaybackSession = false
            playbackInfo.sermonAudio.offsetInMilliseconds = 0;
            return controller.play(handlerInput);
          }

          message = `You were listening to ${playbackInfo.sermonAudio.lastItem.Title}. Would you like to resume?`;
          reprompt = 'You can say yes to resume or no to play from the top.';

        }

        return handlerInput.responseBuilder
          .speak(message)
          .reprompt(reprompt)
          .getResponse();
    },
};

const TipOfTheWeekIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'TipOfTheWeekIntent';
      },
      async handle(handlerInput) {
        const playbackInfo = await getPlaybackInfo(handlerInput);
        let message;
        let reprompt;

        playbackInfo.type = "tipOfTheWeek";

        if('value' in handlerInput.requestEnvelope.request.intent.slots.for_date){
          let awsDate = new AmazonDateParser(handlerInput.requestEnvelope.request.intent.slots.for_date.value);
          playbackInfo.forDate = awsDate.startDate.toJSON();
          console.log("START DATE:", playbackInfo.forDate);
        }else{
          playbackInfo.forDate = new Date();
          playbackInfo.forDate = getMonday(playbackInfo.forDate).toJSON();
        }

        console.log("TOTW DATE: ", playbackInfo.forDate);

        await setPlaybackInfo(handlerInput, playbackInfo);

        return controller.play(handlerInput);
       
    },
};

const ThisWeekAtCCVIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'ThisWeekAtCCVIntent';
      },
      async handle(handlerInput) {
        const playbackInfo = await getPlaybackInfo(handlerInput);
        let message;
        let reprompt;

        playbackInfo.type = "thisWeekAtCCV";

        console.log('This Week HANDLER INPUT: ', handlerInput.requestEnvelope.request.intent.slots);
        
        playbackInfo.forDate = new Date();
        playbackInfo.forDate = getMonday(playbackInfo.forDate).toJSON();
        
        console.log("This Week DATE: ", playbackInfo.forDate);
        
        await setPlaybackInfo(handlerInput, playbackInfo);

        return controller.play(handlerInput);
        
    },
};

const AudioPlayerEventHandler = {
    canHandle(handlerInput) {
        console.log('TYPE: ',handlerInput.requestEnvelope.request.type);
        return handlerInput.requestEnvelope.request.type.startsWith('AudioPlayer.');
    },
    async handle(handlerInput) {

        let audioDate = null;
        let channelId = 8;
        let filterString = null;

        const {
          requestEnvelope,
          attributesManager,
          responseBuilder
        } = handlerInput;

        const audioPlayerEventName = requestEnvelope.request.type.split('.')[1];

        const {
          playbackSetting,
          playbackInfo
        } = await attributesManager.getPersistentAttributes();

        channelId = constants.contentChannels[playbackInfo.type];

        console.log('PLAYBACK TYPE: ', playbackInfo.type);

        switch (audioPlayerEventName) {
          case 'PlaybackStarted':
            playbackInfo[playbackInfo.type].token = getToken(handlerInput);
            playbackInfo[playbackInfo.type].index = await getIndex(handlerInput, playbackInfo.type);
            playbackInfo[playbackInfo.type].inPlaybackSession = true;
            playbackInfo[playbackInfo.type].hasPreviousPlaybackSession = true;
            playbackInfo[playbackInfo.type].lastItem = constants.audioData[playbackInfo.type][0];
            break;
          case 'PlaybackFinished':
            playbackInfo[playbackInfo.type].inPlaybackSession = false;
            playbackInfo[playbackInfo.type].hasPreviousPlaybackSession = false;
            playbackInfo[playbackInfo.type].nextStreamEnqueued = false;
            break;
          case 'PlaybackStopped':
            playbackInfo[playbackInfo.type].token = getToken(handlerInput);
            playbackInfo[playbackInfo.type].index = await getIndex(handlerInput, playbackInfo.type);
            playbackInfo[playbackInfo.type].offsetInMilliseconds = getOffsetInMilliseconds(handlerInput);
            break;
          case 'PlaybackNearlyFinished':
            {
              // if (playbackInfo.nextStreamEnqueued) {
              //   break;
              // }

              // const enqueueIndex = (playbackInfo.index + 1) % constants.audioData.length;

              // if (enqueueIndex === 0 && !playbackSetting.loop) {
              //   break;
              // }

              // playbackInfo.nextStreamEnqueued = true;

              // const enqueueToken = playbackInfo.playOrder[enqueueIndex];
              // const playBehavior = 'ENQUEUE';
              // const podcast = constants.audioData[0];
              // const expectedPreviousToken = playbackInfo.token;
              // const offsetInMilliseconds = 0;

              // responseBuilder.addAudioPlayerPlayDirective(
              //   playBehavior,
              //   podcast.AttributeValues.HostedAudioUrl.Vaule,
              //   enqueueToken,
              //   offsetInMilliseconds,
              //   expectedPreviousToken,
              // );
              break;
            }
          case 'PlaybackFailed':
            playbackInfo[playbackInfo.type].inPlaybackSession = false;
            console.log('Playback Failed : %j', handlerInput.requestEnvelope.request.error);
            return;
          default:
            throw new Error('Should never reach here!');
        }
        console.log('PlayBack Info: ', playbackInfo);

        return responseBuilder.getResponse();
    }    
    
};

const doRockRequest = async (endPoint) => {

    endPoint = endPoint || '';

    console.log('ENDPOINT:', endPoint);

    return new Promise( (resolve, reject) =>{

        var options = { 
            host: 'rock.ccv.church', 
            port: '443', 
            path: endPoint, 
            method: 'GET', 
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization-Token': 'PsUKsQGcqVMOWI6N6M6gxgu7'
            } 
        };

        var req = https.request(options, (res) => {

            res.setEncoding('utf8');

            var returnData = "";
            let out = {};

            res.on('data', chunk => {
                returnData = returnData + chunk;
            });

            res.on('end', () => {
                // we have now received the raw return data in the returnData variable.
                // We can see it in the log output via:
                // console.log(JSON.stringify(returnData))
                // we may need to parse through it to extract the needed data
                // 
                // 
                console.log("RETURN DATA:", returnData);

                out = JSON.parse(returnData);              

                resolve(out);

            });

        });

        req.on('error', (e) => {
            console.error('REQUEST ERROR: ',e);
            reject(null);
        });

        req.end();

    });

}

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speechText = 'You can ask me for the verse of the day, this weeks Sermon audio, or the Coaches tip of the week!  You can also ask me what\'s happening this week.';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withSimpleCard('Christs Church of the Valley', speechText)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speechText = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speechText)
            .withSimpleCard('Christ\'s Church of the Valley', speechText)
            .getResponse();
    }
};

const CheckAudioInterfaceHandler = {
  async canHandle(handlerInput) {
    const audioPlayerInterface = ((((handlerInput.requestEnvelope.context || {}).System || {}).device || {}).supportedInterfaces || {}).AudioPlayer;
    return audioPlayerInterface === undefined
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak('Sorry, this skill is not supported on this device')
      .getResponse();
  },
};

const StartPlaybackHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    if (!playbackInfo[playbackInfo.type].inPlaybackSession) {
      return request.type === 'IntentRequest' && request.intent.name === 'PlayAudio';
    }

    if (request.type === 'PlaybackController.PlayCommandIssued') {
      return true;
    }

    if (request.type === 'IntentRequest') {
      return request.intent.name === 'PlayAudio' ||
        request.intent.name === 'AMAZON.ResumeIntent';
    }
  },
  handle(handlerInput) {
    return controller.play(handlerInput);
  },
};

const NextPlaybackHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      (request.type === 'PlaybackController.NextCommandIssued' ||
        (request.type === 'IntentRequest' && request.intent.name === 'AMAZON.NextIntent'));
  },
  handle(handlerInput) {
    return controller.playNext(handlerInput);
  },
};

const PreviousPlaybackHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      (request.type === 'PlaybackController.PreviousCommandIssued' ||
        (request.type === 'IntentRequest' && request.intent.name === 'AMAZON.PreviousIntent'));
  },
  handle(handlerInput) {
    return controller.playPrevious(handlerInput);
  },
};

const PausePlaybackHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      (request.type === 'IntentRequest' &&
      (request.intent.name === 'AMAZON.StopIntent' ||
        request.intent.name === 'AMAZON.CancelIntent' ||
        request.intent.name === 'AMAZON.PauseIntent' ||
        request)) || (request.type === 'PlaybackController.PauseCommandIssued');
  },
  handle(handlerInput) {
    return controller.stop(handlerInput);
  },
};

const LoopOnHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      request.type === 'IntentRequest' &&
      request.intent.name === 'AMAZON.LoopOnIntent';
  },
  async handle(handlerInput) {
    const playbackSetting = await handlerInput.attributesManager.getPersistentAttributes().playbackSettings;

    playbackSetting.loop = true;

    return handlerInput.responseBuilder
      .speak('Loop turned on.')
      .getResponse();
  },
};

const LoopOffHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      request.type === 'IntentRequest' &&
      request.intent.name === 'AMAZON.LoopOffIntent';
  },
  async handle(handlerInput) {
    const playbackSetting = await handlerInput.attributesManager.getPersistentAttributes().playbackSetting;

    playbackSetting.loop = false;

    return handlerInput.responseBuilder
      .speak('Loop turned off.')
      .getResponse();
  },
};

const ShuffleOnHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      request.type === 'IntentRequest' &&
      request.intent.name === 'AMAZON.ShuffleOnIntent';
  },
  async handle(handlerInput) {

    const speechText = 'Sorry, shuffle is not supported. You can say play, stop or pause.';

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('Christ\'s Church of the Valley', speechText)
      .getResponse();

  },
};

const ShuffleOffHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      request.type === 'IntentRequest' &&
      request.intent.name === 'AMAZON.ShuffleOffIntent';
  },
  async handle(handlerInput) {
    const speechText = 'Sorry, shuffle is not supported. You can say play, stop or pause.';

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('Christ\'s Church of the Valley', speechText)
      .getResponse();
  },
};

const StartOverHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return playbackInfo[playbackInfo.type].inPlaybackSession &&
      request.type === 'IntentRequest' &&
      request.intent.name === 'AMAZON.StartOverIntent';
  },
  async handle(handlerInput) {
    const playbackInfo = await handlerInput.attributesManager.getPersistentAttributes().playbackInfo;

    playbackInfo[playbackInfo.type].offsetInMilliseconds = 0;

    return controller.play(handlerInput);
  },
};

const YesHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return !playbackInfo[playbackInfo.type].inPlaybackSession && request.type === 'IntentRequest' && request.intent.name === 'AMAZON.YesIntent';
  },
  handle(handleInput) {
    return controller.play(handleInput);
  },
};

const NoHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;

    return !playbackInfo[playbackInfo.type].inPlaybackSession && request.type === 'IntentRequest' && request.intent.name === 'AMAZON.NoIntent';
  },
  async handle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);

    playbackInfo[playbackInfo.type].index = 0;
    playbackInfo[playbackInfo.type].offsetInMilliseconds = 0;
    playbackInfo[playbackInfo.type].playbackIndexChanged = true;
    playbackInfo[playbackInfo.type].hasPreviousPlaybackSession = false;

    return controller.play(handlerInput);
  },
};

const ExitHandler = {
  async canHandle(handlerInput) {
    const playbackInfo = await getPlaybackInfo(handlerInput);
    const request = handlerInput.requestEnvelope.request;


    return !playbackInfo.inPlaybackSession &&
      request.type === 'IntentRequest' &&
      (request.intent.name === 'AMAZON.StopIntent' ||
        request.intent.name === 'AMAZON.CancelIntent');
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak('Goodbye!')
      .getResponse();
  },
};

const SystemExceptionHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'System.ExceptionEncountered';
  },
  handle(handlerInput) {
    console.log(`System exception encountered: ${handlerInput.requestEnvelope.request.reason}`);
    const speechText = 'I\'m sorry, but im having a little trouble handling this request.  Please try again.';
    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard('Christ\'s Church of the Valley', speechText)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);
    console.log('Session ended', handlerInput.requestEnvelope);
    return handlerInput.responseBuilder.getResponse();
  },
};

/* HELPER FUNCTIONS */


async function getPlaybackInfo(handlerInput) {
  const attributes = await handlerInput.attributesManager.getPersistentAttributes();
  return attributes.playbackInfo;
}

async function setPlaybackInfo(handlerInput, data){
    let attributes = await handlerInput.attributesManager.getPersistentAttributes();
    attributes.playbackInfo = data;
    handlerInput.attributesManager.setPersistentAttributes(attributes);
    return handlerInput.attributesManager.savePersistentAttributes();
}

async function canThrowCard(handlerInput) {
  const {
    requestEnvelope,
    attributesManager
  } = handlerInput;
  const playbackInfo = await getPlaybackInfo(handlerInput);

  if (requestEnvelope.request.type === 'IntentRequest' && playbackInfo[playbackInfo.type].playbackIndexChanged) {
    playbackInfo[playbackInfo.type].playbackIndexChanged = false;
    return true;
  }
  return false;
}

const controller = {
  async play(handlerInput) {
    let speechText = '';
    let audioUrl = '';
    const {
      attributesManager,
      responseBuilder
    } = handlerInput;

    const playbackInfo = await getPlaybackInfo(handlerInput);

    console.log("PLAY: ", playbackInfo);

    let aDate = new Date(playbackInfo.forDate);

    await updateRockData(playbackInfo.type, aDate);

    switch(playbackInfo.type){
      case 'tipOfTheWeek' :
        speechText = "We're sorry, but we couldn't find any tips of the week for this week.  Can I find something else for you?."
        break;
      case 'sermonAudio' : 
        speechText = "We're sorry, but we couldn't find any Sermon Audio for this week.  Can I find something else for you?"
        break;
      case 'thisWeekAtCCV':
        speechText = "We're sorry, but we couldn't find any scheduled items for this week.  Can I find something else for you?"
        break;
    }

    if(!constants.audioData[playbackInfo.type].length){
      return handlerInput.responseBuilder
      .speak(speechText)
      .withSimpleCard('Christ\'s Church of the Valley', speechText)
      .reprompt()
      .getResponse();
    }

    const {
      offsetInMilliseconds,
      index
    } = playbackInfo[playbackInfo.type];

    const playBehavior = 'REPLACE_ALL';

    let podcast = null;

    if(playbackInfo.type == 'sermonAudio' && playbackInfo[playbackInfo.type].hasPreviousPlaybackSession && playbackInfo[playbackInfo.type].lastItem){
      podcast = playbackInfo[playbackInfo.type].lastItem;
    }else{
      podcast = constants.audioData[playbackInfo.type][0];
    }

    const token = podcast.Guid;

    let offset = 0;

    switch(playbackInfo.type){
      case 'tipOfTheWeek' :
        audioUrl = podcast.AttributeValues.WeeklyCoachTips.Value;
        offset = 0;
        break;
      case 'sermonAudio' : 
        audioUrl = podcast.AttributeValues.HostedAudioUrl.Value;
        offset = offsetInMilliseconds;
        break;
      case 'thisWeekAtCCV':
        audioUrl = podcast.AttributeValues.ThisWeekatCCV.Value;
        offset = 0;
        break;
    }

    if( (playbackInfo.type == 'thisWeekAtCCV') && (podcast.AttributeValues.ThisweekatCCVtext.Value.length > 2) ){
      speechText = podcast.AttributeValues.ThisweekatCCVtext.Value
      return handlerInput.responseBuilder
      .speak(speechText)
      .withSimpleCard('This Week at Christ\'s Church of the Valley: ', speechText)
      .reprompt()
      .getResponse();
    }

    if(!audioUrl){
        speechText = "We're sorry, but there was a problem finding your requested data.  Please try again.";
        return handlerInput.responseBuilder
          .speak(speechText)
          .withSimpleCard("Chirst's Church of the Valley", speechText)
          .reprompt()
          .getResponse();
    }

    playbackInfo[playbackInfo.type].token = token;

    if(playbackInfo.type == 'tipOfTheWeek'){
      speechText = `This is the ${podcast.Title}`;
    }else{
      speechText = `This is ${podcast.Title}`;
    }

    responseBuilder
      .speak(speechText)
      .addAudioPlayerPlayDirective(playBehavior, audioUrl, token, offset, null)
      .reprompt();

    if (await canThrowCard(handlerInput)) {
      const cardTitle = `Playing ${podcast.Title}`;
      const cardContent = `${podcast.Content}`;
      responseBuilder.withSimpleCard(cardTitle, cardContent);
    }

    return responseBuilder.getResponse();

  },
  stop(handlerInput) {
    return handlerInput.responseBuilder
      .addAudioPlayerStopDirective()
      .getResponse();
  },
  async playNext(handlerInput) {

    console.log('PLAY NEXT');
    const {
      playbackInfo,
      playbackSetting,
    } = await handlerInput.attributesManager.getPersistentAttributes();

    const nextIndex = (playbackInfo[playbackInfo.type].index + 1) % constants.audioData[playbackInfo.type].length;

    if (nextIndex === 0 && !playbackSetting.loop) {
      return handlerInput.responseBuilder
        .speak('You have reached the end of the playlist')
        .addAudioPlayerStopDirective()
        .getResponse();
    }

    playbackInfo[playbackInfo.type].index = nextIndex;
    playbackInfo[playbackInfo.type].offsetInMilliseconds = 0;
    playbackInfo[playbackInfo.type].playbackIndexChanged = true;

    return this.play(handlerInput);

  },
  async playPrevious(handlerInput) {
    const {
      playbackInfo,
      playbackSetting,
    } = await handlerInput.attributesManager.getPersistentAttributes();

    let previousIndex = playbackInfo[playbackInfo.type].index - 1;

    if (previousIndex === -1) {
      if (playbackSetting.loop) {
        previousIndex += constants.audioData[playbackInfo.type].length;
      } else {
        return handlerInput.responseBuilder
          .speak('You have reached the start of the playlist')
          .addAudioPlayerStopDirective()
          .getResponse();
      }
    }

    playbackInfo[playbackInfo.type].index = previousIndex;
    playbackInfo[playbackInfo.type].offsetInMilliseconds = 0;
    playbackInfo[playbackInfo.type].playbackIndexChanged = true;

    return this.play(handlerInput);
  },
};

function getToken(handlerInput) {
  // Extracting token received in the request.
  return handlerInput.requestEnvelope.request.token;
}

async function getIndex(handlerInput,type) {
  // Extracting index from the token received in the request.
  const attributes = await handlerInput.attributesManager.getPersistentAttributes();
  return attributes.playbackInfo[type].index;
}

function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}

async function updateRockData(type,audioDate){

    let out = null;
    let aData = {};

    type = type || 'sermonAudio';
    audioDate = audioDate || new Date();

    switch(type) {
        case 'sermonAudio':
          audioDate.setDate( audioDate.getDate() - (audioDate.getDay()+1) );
          aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true)+'&LoadAttributes=True');
          if(aData.length<1){
              adate.setDate( audioDate.getDate() - 7);
              aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true, true)+'&LoadAttributes=True');
          }
        break;
        case 'tipOfTheWeek':
            aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true)+'&LoadAttributes=True');
            if(aData.length<1){
              aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true, true)+'&LoadAttributes=True');
            }
        break;
        case 'thisWeekAtCCV':
            aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true)+'&LoadAttributes=True');
            if(aData.length < 1){
              aData = await doRockRequest('/api/ContentChannelItems?$filter='+getFilterString(constants.contentChannels[type], audioDate, true, true)+'&LoadAttributes=True');
            }
        break;
                
    }

    aData.sort(dateSortDesc);

    console.log('aData Sorted: ', aData);

    constants.audioData[type] = aData;

}

/**
 * Returns a properly formatted filter string for rock requests.
 * @param  {Date} filterDate  a date object for to search for.  If not included, todays date will be used.
 * @param  {Int} channelId   The channel to search
 * @param  {Bool} searchByDay whether or not to search by specific day.  If false the filter string will be generated with the month and year only.
 * @return {String} a Uri encoded string.         
 */
function getFilterString(channelId,filterDate,searchByDay,getAll){

    channelId = parseInt(channelId);
    filterDate = filterDate || new Date();
    searchByDay = searchByDay || false;
    getAll = getAll || false;

    console.log("FILTER DATE: ", filterDate);

    let filterString = 'ContentChannelTypeId eq '+ 
                    channelId;

    if(channelId == 254){
      filterString = 'ContentChannelId eq '+ 
                    channelId;
    }

    if(getAll){
      return encodeURIComponent(filterString);
    }

    if(searchByDay){
        filterString += ' and day(StartDateTime) eq ' + filterDate.getDate();
    }
    
    
    filterString += ' and month(StartDateTime) eq ' +
        (filterDate.getMonth()+1);
    
    
    filterString += ' and year(StartDateTime) eq '+
                    filterDate.getFullYear();

    return encodeURIComponent(filterString);

}

function getOffsetInMilliseconds(handlerInput) {
  // Extracting offsetInMilliseconds received in the request.
  return handlerInput.requestEnvelope.request.offsetInMilliseconds;
}

function dateSortDesc (a, b) {
  // This is a comparison function that will result in dates being sorted in
  // DESCENDING order.
  
  if( (a.StartDateTime.length < 1) && (b.StartDateTime.length > 1) ){
    return -1;
  }

  if( (b.StartDateTime.length < 1) && (a.StartDateTime.length > 1) ){
    return 1;
  }

  let aDate = new Date(a.StartDateTime);
  let bDate = new Date(b.StartDateTime);

  if (aDate > bDate) return -1;
  if (aDate < bDate) return 1;
  return 0;

};

function shuffleOrder() {
  const array = [...Array(constants.audioData[playbackInfo.type].length).keys()];
  let currentIndex = array.length;
  let temp;
  let randomIndex;
  // Algorithm : Fisher-Yates shuffle
  return new Promise((resolve) => {
    while (currentIndex >= 1) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
      temp = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temp;
    }
    resolve(array);
  });
}

const ErrorHandler = {
    canHandle() {
      return true;
    },
    handle(handlerInput, error) {
      console.log('Error handled: ', error);

      return handlerInput.responseBuilder
        .speak('Sorry, I can\'t understand the command. Please say again.')
        .reprompt('Sorry, I can\'t understand the command. Please say again.')
        .getResponse();
    },
};