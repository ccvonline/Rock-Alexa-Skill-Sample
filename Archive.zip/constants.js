/* CONSTANTS */

exports.skill = {
  appId: '',
  dynamoDBTableName: 'SermonAudio-Stream',
};

exports.audioData = {
  sermonAudio:[],
  tipOfTheWeek:[],
  thisWeekAtCCV:[]
};

exports.contentChannels = {
  sermonAudio: 8,
  tipOfTheWeek: 254,
  thisWeekAtCCV: 254,
  vod: 249
}